# Nav Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/nilbog/pen/gONmOr](https://codepen.io/nilbog/pen/gONmOr).

Quick example of a drop-down nav bar;  pushes content down but also allows for scrolling